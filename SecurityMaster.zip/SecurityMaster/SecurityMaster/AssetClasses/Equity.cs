﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecurityMaster.AssetClasses
{
    public class Equity:SecurityBase
    {
        public Equity()
        {
            _assetType = AssetType.Equity;   
        }

        public override AssetType AssetType
        {
            get
            {
                return base.AssetType;
            }
        }
    }
}
