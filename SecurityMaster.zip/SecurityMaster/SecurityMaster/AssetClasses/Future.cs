﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecurityMaster.AssetClasses
{
    public class Future:SecurityBase
    {
        public DateTime ExpirationDate { get; set; }
        public int ContractSize { get; set; }

        public override AssetType AssetType
        {
            get
            {
                return base.AssetType;
            }
        }

        public Future()
        {
            _assetType = AssetType.Future;
        }
    }
}
