﻿using SecurityMaster.AssetClasses;
using SecurityMaster.Calculators;
using SecurityMaster.MarketData;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SecurityMaster.Calculators.MarketValueCalculator;

namespace SecurityMaster
{
    public class SecuritiesController
    {
        public Dictionary<SecurityMarketValueViewModel, double> CalculateMarketValue(DateTime date)
        {
            var dictMarketValue = new Dictionary<SecurityMarketValueViewModel, double>();
            List<Position> positions = GetPositions(date);
            List<SecurityBase> securities = GetAllSecurities();
            List<TickerPrice> prices = GetPrices(date);
            foreach (SecurityBase security in securities)
            {
                IMarketValueCalculator mvCalculator = CalculatorFactory.GetMarketValueCalculatorByAssetType(security.AssetType);
                var position = positions.Where(p => p.Ticker == security.Ticker).SingleOrDefault();
                var price = prices.Where(pr => pr.Ticker == security.Ticker).SingleOrDefault();
                var marketValue = mvCalculator.CalculateMarketValue(security, position, price);
                dictMarketValue.Add(new SecurityMarketValueViewModel { Ticker = security.Ticker, Quantity = position.Quantity, Price = price.Price, TradeDate = price.PriceDate }, marketValue);
            }
            return dictMarketValue;
        }

        //stub method
        private List<TickerPrice> GetPrices(DateTime date)
        {
            return new List<TickerPrice> {
            new TickerPrice { Ticker ="AAPL",Price=600, PriceDate = DateTime.Parse("4/15/2016") },
            new TickerPrice { Ticker ="AAPL-PUT620-Mar16",Price=500, PriceDate = DateTime.Parse("4/15/2016") },
            new TickerPrice { Ticker = "AAPL00000123", Price = 650, PriceDate = DateTime.Parse("4/15/2016") },};
    }

        //stub method
        private List<SecurityBase> GetAllSecurities()
        {
            List<SecurityBase> listSecurities = new List<SecurityBase>();
            return new List<SecurityBase>
            {
               new Equity { MasterSecID = 1, Ticker = "AAPL", Currency ="USD",Name = "Apple" },
               new Option { MasterSecID = 2, Ticker = "AAPL-PUT620-Mar16", Currency ="USD",Name = "Apple", ContractSize = 100 },
               new Future { MasterSecID = 3, Ticker = "AAPL00000123", Currency ="USD",Name = "Apple", ContractSize = 100 },
            };
        }

        //stub method
        private List<Position> GetPositions(DateTime date)
        {
            return new List<Position>
            {
                new Position {  Ticker = "AAPL", Quantity =100},
                new Position {  Ticker = "AAPL-PUT620-Mar16", Quantity =100},
                new Position {  Ticker = "AAPL00000123", Quantity =10},
            };
        }
    }


    [TestClass]
    public class SecurityContollerTest
    {
        [TestMethod]
        public void TestCalculateMarketValue()
        {
            var result = new SecuritiesController().CalculateMarketValue(DateTime.Parse("4/18/2016"));
            Assert.AreEqual(60000, result.Where(kv => kv.Key.Ticker == "AAPL").Select(kv => kv.Value).SingleOrDefault());
            Assert.AreEqual(5000000, result.Where(kv => kv.Key.Ticker == "AAPL-PUT620-Mar16").Select(kv => kv.Value).SingleOrDefault());
            Assert.AreEqual(650000, result.Where(kv => kv.Key.Ticker == "AAPL00000123").Select(kv => kv.Value).SingleOrDefault());
        }
    }
}