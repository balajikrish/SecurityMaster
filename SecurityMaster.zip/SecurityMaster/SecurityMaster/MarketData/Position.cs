﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SecurityMaster.MarketData
{
    public class Position
    {
        public string Ticker { get; set; }
        public long Quantity { get; set; }
    }
}
