﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SecurityMaster.AssetClasses;
using SecurityMaster.MarketData;

namespace SecurityMaster.Calculators.MarketValueCalculator
{
    public class EquityMarketValueCalculator : IMarketValueCalculator
    {
        public double CalculateMarketValue(SecurityBase security, Position position, TickerPrice tickerPrice)
        {
            return position.Quantity * tickerPrice.Price;
        }
    }
}
