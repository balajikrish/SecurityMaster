﻿using SecurityMaster.AssetClasses;
using SecurityMaster.Calculators.MarketValueCalculator;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StructureMap;

namespace SecurityMaster.Calculators
{
    public static class CalculatorFactory
    {       
        static CalculatorFactory()
        {
            ObjectFactory.Configure(x => x.AddConfigurationFromXmlFile("StructureMap.xml"));
        }

        public static IMarketValueCalculator GetMarketValueCalculatorByAssetType (AssetType assetType)
        {

            var marketValueCalcuator = ObjectFactory.GetNamedInstance<IMarketValueCalculator>(assetType.ToString());
            return marketValueCalcuator;
        }
    }
}
